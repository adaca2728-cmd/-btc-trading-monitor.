BTC Trading Monitor — versão gratuita

Conteúdo:
- index.html: painel LONG/SHORT
- manifest.webmanifest: metadados para instalação como PWA
- service-worker.js: cache básico para abrir a interface offline (dados exigem internet)

Dados:
- Binance Futures public API, BTCUSDT.
- Atualiza apenas enquanto a página está aberta.
- SHORT: alerta quando uma vela de 1h FECHADA cruza para baixo do nível configurado (padrão US$58.700).
- LONG: heurística simples baseada em EMAs 9/21 e movimento do preço. É um aviso preliminar, não sinal profissional nem recomendação.

Como usar agora:
Abra index.html no navegador com internet. Para adicionar à tela inicial do iPhone com experiência de app, publique os arquivos em um host HTTPS gratuito, por exemplo GitHub Pages, e no Safari use Compartilhar > Adicionar à Tela de Início.
